package panel;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import components.ListJTable;
import frame.NewStockMarketFrame;
import implementation.StockMarketImplementation;
import statics.Bundle;

public class StockMarketPanel extends JPanel implements ActionListener{
	
	private JButton addNewButton;
	private StockMarketImplementation stockMarketImplementation;
	private ListJTable stockTable;

	public StockMarketPanel() {
		super();
		this.setLayout(new BorderLayout());
		
		addNewButton = new JButton(Bundle.ADD_NEW);
		addNewButton.addActionListener(this);
		
		stockMarketImplementation = new StockMarketImplementation();
		
		stockTable = new ListJTable(stockMarketImplementation.getAllForTable(), stockMarketImplementation.getColumnsForTable());
		JScrollPane scrollPane = new JScrollPane(stockTable);
		
		JPanel centerPanel = new JPanel(new BorderLayout());
		centerPanel.add(scrollPane, BorderLayout.CENTER);
		
		JPanel bottomPanel = new JPanel(new BorderLayout());
		JPanel newButtonStockPanel = new JPanel();
		
		newButtonStockPanel.add(addNewButton);
		bottomPanel.add(new BorderLayoutPanelNorth(newButtonStockPanel), BorderLayout.EAST);
		
		this.add(centerPanel, BorderLayout.CENTER);
		this.add(bottomPanel, BorderLayout.SOUTH);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(Bundle.ADD_NEW)) {
			NewStockMarketFrame newStockMarketFrame = new NewStockMarketFrame();
			newStockMarketFrame.setVisible(true);
		}
	}
	
}
