package panel;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class RootPanel extends JPanel{

	private static final long serialVersionUID = 1L;

	public RootPanel() {
		super();
		
		JPanel p1 = new JPanel();
		p1.add(new StockMarketPanel(),BorderLayout.CENTER);
		
		JPanel p2 = new JPanel();
		p2.add(new JLabel("Time Deposit"));
		
		JPanel p3 = new JPanel();
		p3.add(new JLabel("Commercial Item"));
		
		JTabbedPane tabbedPane = new JTabbedPane();
		
		tabbedPane.add("Stock Market", p1);
		tabbedPane.addTab("Time Deposit", p2);
		
		this.setLayout(new BorderLayout());
		
		this.add(tabbedPane, BorderLayout.CENTER);
	}

}
