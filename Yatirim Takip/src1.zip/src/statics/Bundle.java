package statics;

public class Bundle {
	
	public static final String LOGIN_BUTTON_TEXT = "Login";
	public static final String REGISTER_BUTTON_TEXT = "Register";
	public static final String FORGOT_PASSWORD_TEXT = "Forgot Password";
	

}
