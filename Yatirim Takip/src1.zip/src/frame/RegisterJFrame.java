package frame;


import javax.swing.JFrame;

public class RegisterJFrame extends JFrame {
	
	public RegisterJFrame() {
		super();
		this.setTitle("Register");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(400, 400);
		this.setLocationRelativeTo(null);
		
		
		this.invalidate();
		this.validate();
		this.repaint();
		
	}

}
