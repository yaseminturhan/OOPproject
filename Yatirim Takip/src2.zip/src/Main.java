import javax.swing.JFrame;

import frame.LoginJFrame;
import implementation.UserDaoImplementation;
import pojo.User;

public class Main {

	public static void main(String[] args) {
		
		//User user = new User("koray", "Ozyurt", "kozyurt", "test123", 950000, 5, "dedenizin meslegi", "metin2");
		//UserDaoImplementation userDaoImplementation = new UserDaoImplementation();
		//userDaoImplementation.save(user);
		
		LoginJFrame loginJframe = new LoginJFrame();
		
	}
}
