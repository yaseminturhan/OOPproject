package statics;

import pojo.User;

public class Global {
	
	public static User user;
	

}
