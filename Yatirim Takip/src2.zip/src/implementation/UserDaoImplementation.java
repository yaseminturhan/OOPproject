package implementation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import interfaces.IDao;
import pojo.User;
import statics.Global;

public class UserDaoImplementation extends FileProcess implements IDao<User>{
	
	private static final String FILE_NAME= "user.txt";

	@Override
	public void save(User t) {
		t.setId(super.getLastId(FILE_NAME));
		t.setDate(new Date().toString());
		super.writeFile(FILE_NAME, t.toString());
	}

	@Override
	public void update(String id, User t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> getAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public boolean login(String userName, String password) {
		ArrayList<String> users = super.readLines(FILE_NAME);
		for(String line : users) {
			String[] attr = line.split("___");
			if(attr[4].equals(userName) && attr[5].equals(password)) {
				User user = new User(Integer.parseInt(attr[0]), attr[1], attr[2], attr[3], 
						attr[4], attr[5], Double.parseDouble(attr[6]), Double.parseDouble(attr[7]), attr[8], attr[9]);
				Global.user = user;
				return true;
			}
		}
		return false;
	}
	
	public String findPassword(String userName, String secQuestion, String secAnswer) {
		ArrayList<String> users = super.readLines(FILE_NAME);
		for(String line : users) {
			String[] attr = line.split("___");
			if(attr[4].trim().equals(userName) && attr[8].trim().equals(secQuestion) && attr[9].trim().equals(secAnswer)) {
				return attr[5];
			}
		}
		return null;
	}

	public String findSecurityQuestion(String userName) {
		ArrayList<String> users = super.readLines(FILE_NAME);
		for(String line : users) {
			String[] attr = line.split("___");
			if(attr[4].equals(userName) ) {
				return attr[8];
			}
		}
		return "";
	}

}
