package pojo;

import java.util.Date;

public class Stock extends Entity{

	private String company;
	private int numberOfStock;
	private double unitPrice;
	private double totalPrice;
	
	public Stock(String company, int numberOfStock, double unitPrice, double totalPrice) {
		super();
		this.company = company;
		this.numberOfStock = numberOfStock;
		this.unitPrice = unitPrice;
		this.totalPrice = totalPrice;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public int getNumberOfStock() {
		return numberOfStock;
	}

	public void setNumberOfStock(int numberOfStock) {
		this.numberOfStock = numberOfStock;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return super.toString() + company + "\t" + numberOfStock + "\t" + unitPrice + "\t" + totalPrice;
	}
	
	
	
}
