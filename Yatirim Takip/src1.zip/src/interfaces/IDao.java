package interfaces;

import java.util.List;

public interface IDao<T> {
	
	void save(T t);
	void update(String id, T t);
	void delete(T t);
	List<T> getAll();
}
