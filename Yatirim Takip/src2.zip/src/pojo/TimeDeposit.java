package pojo;

import java.util.Date;

import constant.InterestPeriod;

public class TimeDeposit extends Entity{
	
	private double balance;
	private double interest;
	private InterestPeriod interestPeriod;

	public TimeDeposit(double balance, double interest, InterestPeriod interestPeriod) {
		this.balance = balance;
		this.interest = interest;
		this.interestPeriod = interestPeriod;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getInterest() {
		return interest;
	}

	public void setInterest(double interest) {
		this.interest = interest;
	}

	public InterestPeriod getInterestPeriod() {
		return interestPeriod;
	}

	public void setInterestPeriod(InterestPeriod interestPeriod) {
		this.interestPeriod = interestPeriod;
	}

	@Override
	public String toString() {
		return super.toString() 
				+ "___" + balance + "___" + interest + "___" + interestPeriod;
	}

}
