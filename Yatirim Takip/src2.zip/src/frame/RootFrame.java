package frame;

import java.awt.HeadlessException;

import javax.swing.JFrame;

import panel.RootPanel;

public class RootFrame extends JFrame{

	public RootFrame() throws HeadlessException {
		super();
		
		this.setTitle("Finance");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setSize(450, 210);
		this.setLocationRelativeTo(null);
		
		RootPanel rootPanel = new RootPanel();
		this.add(rootPanel);
		
		this.invalidate();
		this.validate();
		this.repaint();
	}

}
