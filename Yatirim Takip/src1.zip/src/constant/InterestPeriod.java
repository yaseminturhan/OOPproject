package constant;

public enum InterestPeriod {
	DAILY,
	MONTHLY,
	ANNUAL
}
