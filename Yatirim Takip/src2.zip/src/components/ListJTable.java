package components;

import java.util.ArrayList;

import javax.swing.JTable;

public class ListJTable extends JTable {
	
	private String[][] data;
	private String[] column;
	
	private ArrayList<ArrayList<String>> dataA;
	private ArrayList<String> columnA;
	
	public ListJTable(ArrayList<ArrayList<String>> dataA, ArrayList<String> columnA) {
		super();
		this.dataA = dataA;
		this.columnA = columnA;
		
		listToData();
		
	}
	
	private void listToData(){
		this.data = new String[this.dataA.size()][this.dataA.get(0).size()];
		for(int i=0;i<this.dataA.size();i++) {
			for(int j =0; j < this.dataA.get(i).size(); j++) {
				this.data[i][j] = this.dataA.get(i).get(j);
			}
		}
		this.column = columnA.toArray(new String[columnA.size()]);
		this.updateData();
	}
	
	private void updateData() {
		for(int i=0; i< this.data.length; i++) {
			for(int j=0; j< this.data[i].length; j++) {
				this.getModel().setValueAt(data[i][j], i, j);
			}
		}
	}

	public ArrayList<ArrayList<String>> getDataA() {
		return dataA;
	}

	public void setDataA(ArrayList<ArrayList<String>> dataA) {
		this.dataA = dataA;
		listToData();
	}

	public ArrayList<String> getColumnA() {
		return columnA;
	}

	public void setColumnA(ArrayList<String> columnA) {
		this.columnA = columnA;
		listToData();
	}

	

}
