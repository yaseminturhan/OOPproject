package statics;

public class Bundle {

	// General
	public static final String ADD_NEW = "Add New";
	public static final String CANCEL_BUTTON = "Cancel";

	// Login
	public static final String LOGIN_BUTTON = "Login";
	public static final String REGISTER_BUTTON = "Register";
	public static final String FORGOT_PASSWORD = "Forgot Password";

	// Register

	// Forgot Password
	public static final String SHOW_ME_PASSWORD = "Show me password";

	
	// Stock Market
	
}
